# LocalApply privacy policy

Last updated: 22 October 2026

LocalApply is a browser extension that fills job application forms with information you save in it. This policy explains what information it handles and what happens to it. In short: everything stays in your browser, on your device. Nothing is sent to the developer or anyone else.

## What information LocalApply handles

What you enter on its profile page, and the application log described below:

- **Personal and contact details:** name, salutation, email address, phone number, date of birth, nationality and postal address.
- **Professional details:** links (LinkedIn, GitHub, Xing, portfolio), work history (job titles, employers, locations, dates and what you did), education (schools, degrees, fields of study and dates) and highest education level, spoken languages and their level, salary expectation and range, notice period, earliest start date, years of experience, work authorisation, visa sponsorship, relocation and travel preferences, and driving licence.
- **Documents:** your CV and cover letter files, and cover letter text.
- **Several profiles**, if you make more than one (for example one per language): each holds its own copy of the above, under a name you choose.
- **Saved answers** to application questions.
- **Optional voluntary disclosures**, only if you fill them in: gender, sexual orientation, disability status and veteran status.

To decide which form field needs which piece of your information, LocalApply reads the labels and structure of the form on the page you ask it to fill. When you ask it to fill a page, it also reads the employer's name and the job title from that page, to put them into your cover letter and saved answers where you wrote {company} or {position}. It never sends anything it reads from web pages anywhere, and it does not record the sites you browse.

## Application log

So you can see where you applied, LocalApply notes each application form it fills: the date, the employer's name and job title as read from the page, the name of the profile that filled it, and the page's address without anything after it (no "?…" query, which can contain tokens). The log is on unless you turn it off, and is stored only in your browser like your profile. On the profile page, under Applications, you can turn it off, remove single entries, clear it, or export it as a CSV file. Nothing is noted for pages you only visit, and "Delete all data" clears the log too.

## How the information is used

Solely to fill application forms you choose to fill: when you click "Fill this page" or press the keyboard shortcut. LocalApply never submits a form for you.

## Where it is stored

In your browser's extension storage on your own device. It is not synced to an account and not uploaded anywhere.

## Sharing

LocalApply has no server, no analytics and no advertising, and makes no network requests. The developer never receives your information and does not sell, share or transfer it to anyone. The information reaches a website only when you ask LocalApply to fill that website's form, and you then decide whether to submit it.

## Keeping, exporting and deleting your information

Your information stays until you change or delete it. On the profile page you can export your profile to a file, export the application log as CSV, or delete it all with "Delete all data". Removing the extension also deletes everything it stored.

## Chrome Web Store User Data Policy

The use of information received from Chrome APIs adheres to the [Chrome Web Store User Data Policy](https://developer.chrome.com/docs/webstore/program-policies/user-data-faq), including the Limited Use requirements. Your information is used only to provide LocalApply's single purpose of filling job application forms. It is not transferred to anyone, not used for advertising, and not read by any person.

## Changes

If this policy changes, the new version will be published at this address with a new date, and changes in what LocalApply handles will also be noted in its [changelog](CHANGELOG.md).

## Contact

Questions or concerns: open an issue at [github.com/somewordshere/LocalApply/issues](https://github.com/somewordshere/LocalApply/issues).
