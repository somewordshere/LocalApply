export type FieldKind =
  'text' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'checkgroup' | 'file' | 'date' | 'combobox';

export type FieldKey =
  | 'salutation'
  | 'firstName'
  | 'lastName'
  | 'fullName'
  | 'email'
  | 'phone'
  | 'phoneCountryCode'
  | 'dateOfBirth'
  | 'nationality'
  | 'street'
  | 'houseNumber'
  | 'postcode'
  | 'city'
  | 'state'
  | 'country'
  | 'location'
  | 'linkedin'
  | 'github'
  | 'website'
  | 'xing'
  | 'salary'
  | 'salaryMin'
  | 'salaryMax'
  | 'salaryCurrency'
  | 'noticePeriod'
  | 'startDate'
  | 'workAuthorized'
  | 'needsSponsorship'
  | 'willingToRelocate'
  | 'willingToTravel'
  | 'drivingLicence'
  | 'drivingLicenceClass'
  | 'remotePreference'
  | 'yearsOfExperience'
  | 'currentTitle'
  | 'currentEmployer'
  | 'workLocation'
  | 'workDescription'
  | 'workStart'
  | 'workEnd'
  | 'workStartYear'
  | 'workEndYear'
  | 'educationStart'
  | 'educationEnd'
  | 'educationStartYear'
  | 'educationEndYear'
  | 'school'
  | 'educationLevel'
  | 'degree'
  | 'fieldOfStudy'
  | 'languages'
  | 'languageLevel'
  | 'coverLetterText'
  | 'cv'
  | 'coverLetterFile'
  | 'gender'
  | 'sexualOrientation'
  | 'disability'
  | 'veteran';

export interface FieldOption {
  text: string;
  value: string;
  el: HTMLElement;
}

export interface Field {
  /** The control itself; for a radio group, its first radio. */
  el: HTMLElement;
  kind: FieldKind;
  /** Input type attribute, lowercased ('' for non-inputs). */
  type: string;
  label: string;
  /** name, id and test/automation ids, raw. */
  attrs: string[];
  autocomplete: string[];
  placeholder: string;
  required: boolean;
  /** Options of a select or radio group. */
  options: FieldOption[];
}

export interface FillResult {
  adapter: string | null;
  /** Fields found on the page. */
  total: number;
  filled: { label: string; key: string }[];
  /** Recognised fields whose value is empty in the profile. */
  missing: { label: string; key: string }[];
  /** Fields that could not be mapped or set. */
  unmatched: { label: string; required: boolean }[];
  /** Fields left alone because they already had a value. */
  skipped: number;
  /** Every field found, with the profile key it matched and what happened to it: "Why wasn't this filled?". */
  fields?: { label: string; key: string | null; outcome: FieldOutcome }[];
  /** Saved answers this fill used, by id. */
  usedAnswers?: string[];
  /** Job and education blocks on the form, and whether it has a button to add another. */
  blocks?: Blocks;
}

export type FieldOutcome = 'filled' | 'missing' | 'unmatched' | 'skipped';

export interface Blocks {
  experience: number;
  education: number;
  addExperience: boolean;
  addEducation: boolean;
}
